# Claude Code Agents

A practical collection of agents, tools, skills and workflows for Claude Code.

## Philosophy

- **Ship within a year**: No agent takes more than a year to ROI
- **Follow your doubt**: If it feels wrong, it probably is
- **Prototype the hard thing**: Test the differentiation early
- **Think slow, act fast**: Deep understanding, rapid execution

## Structure

```
agents/          # Complete agent definitions
subagents/       # Reusable agent components
skills/          # Capabilities and knowledge domains
tools/           # Executable utilities
workflows/       # Multi-step processes
examples/        # Real usage patterns
```

See [FILE_ORGANIZATION.md](FILE_ORGANIZATION.md) for detailed file organization best practices optimized for Claude Code.

## Quick Start

1. Browse `agents/` for complete solutions
2. Check `examples/` for actual usage
3. Mix from `subagents/` and `skills/` to build your own
4. Add to `workflows/` when you find repeating patterns

## Contributing to Yourself

When you save something here, answer:
- What problem did this solve?
- What did you learn that wasn't obvious?
- What would you do differently next time?

## Index

See individual folders for catalogs.
