# Agents

Complete, production-ready agents. Each one solves a specific problem end-to-end.

## Template

When you add an agent, include:

```markdown
# Agent Name

## What It Does
One sentence. Be specific.

## Why It Exists
What problem were you actually solving?

## How It Works
Key decisions and tradeoffs.

## Usage
Actual command or invocation.

## Gotchas
What broke? What surprised you?

## Improvements
What would make this 10x better?
```

## Catalog

*Add your agents here as you build them*
