# Skills

Knowledge domains and capabilities. What Claude knows how to do.

## What Goes Here

- Technical knowledge (e.g., "kubernetes_patterns", "sql_optimization")
- Design systems (e.g., "design_tokens", "component_library")
- Business logic (e.g., "pricing_models", "user_onboarding")
- Best practices (e.g., "error_handling", "testing_strategies")

## Organization

Group by domain:
```
skills/
  backend/
  frontend/
  data/
  devops/
  design/
  business/
```

## Format

Each skill should be:
- Specific enough to be actionable
- General enough to be reusable
- Opinionated about what works

## Catalog

*Your skills library*
